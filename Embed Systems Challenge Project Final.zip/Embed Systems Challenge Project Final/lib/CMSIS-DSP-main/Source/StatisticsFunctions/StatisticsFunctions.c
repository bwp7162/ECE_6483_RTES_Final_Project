/* ----------------------------------------------------------------------
 * Project:      CMSIS DSP Library
 * Title:        StatisticsFunctions.c
 * Description:  Combination of all statistics function source files.
 *
 * $Date:        14 July 2022
 * $Revision:    V1.1.1
 *
 * Target Processor: Cortex-M cores
 * -------------------------------------------------------------------- */
/*
 * Copyright (C) 2019-2020 ARM Limited or its affiliates. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "arm_entropy_f32.c"
#include "arm_entropy_f64.c"
#include "arm_kullback_leibler_f32.c"
#include "arm_kullback_leibler_f64.c"
#include "arm_logsumexp_dot_prod_f32.c"
#include "arm_logsumexp_f32.c"
#include "arm_max_f32.c"
#include "arm_max_f64.c"
#include "arm_max_q15.c"
#include "arm_max_q31.c"
#include "arm_max_q7.c"
#include "arm_max_no_idx_f32.c"
#include "arm_max_no_idx_f64.c"
#include "arm_max_no_idx_q31.c"
#include "arm_max_no_idx_q15.c"
#include "arm_max_no_idx_q7.c"
#include "arm_mean_f32.c"
#include "arm_mean_f64.c"
#include "arm_mean_q15.c"
#include "arm_mean_q31.c"
#include "arm_mean_q7.c"
#include "arm_min_f32.c"
#include "arm_min_f64.c"
#include "arm_min_q15.c"
#include "arm_min_q31.c"
#include "arm_min_q7.c"
#include "arm_min_no_idx_f32.c"
#include "arm_min_no_idx_f64.c"
#include "arm_min_no_idx_q31.c"
#include "arm_min_no_idx_q15.c"
#include "arm_min_no_idx_q7.c"
#include "arm_power_f32.c"
#include "arm_power_f64.c"
#include "arm_power_q15.c"
#include "arm_power_q31.c"
#include "arm_power_q7.c"
#include "arm_rms_f32.c"
#include "arm_rms_q15.c"
#include "arm_rms_q31.c"
#include "arm_std_f32.c"
#include "arm_std_f64.c"
#include "arm_std_q15.c"
#include "arm_std_q31.c"
#include "arm_var_f32.c"
#include "arm_var_f64.c"
#include "arm_var_q15.c"
#include "arm_var_q31.c"
#include "arm_absmax_f32.c"
#include "arm_absmax_f64.c"
#include "arm_absmax_q15.c"
#include "arm_absmax_q31.c"
#include "arm_absmax_q7.c"
#include "arm_absmin_f32.c"
#include "arm_absmin_f64.c"
#include "arm_absmin_q15.c"
#include "arm_absmin_q31.c"
#include "arm_absmin_q7.c"
#include "arm_absmax_no_idx_f32.c"
#include "arm_absmax_no_idx_f64.c"
#include "arm_absmax_no_idx_q15.c"
#include "arm_absmax_no_idx_q31.c"
#include "arm_absmax_no_idx_q7.c"
#include "arm_absmin_no_idx_f32.c"
#include "arm_absmin_no_idx_f64.c"
#include "arm_absmin_no_idx_q15.c"
#include "arm_absmin_no_idx_q31.c"
#include "arm_absmin_no_idx_q7.c"
#include "arm_mse_q7.c"
#include "arm_mse_q15.c"
#include "arm_mse_q31.c"
#include "arm_mse_f32.c"
#include "arm_mse_f64.c"
#include "arm_accumulate_f32.c"
#include "arm_accumulate_f64.c"


